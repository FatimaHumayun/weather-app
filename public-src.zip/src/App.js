import Directory from "./pages/Directory.jsx";

function App() {
  return (
    <>
      <div className="App">
        <Directory></Directory>
      </div>
    </>
  );
}
export default App;
